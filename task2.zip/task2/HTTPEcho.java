import java.net.*;
import java.io.*;

public class HTTPEcho {
    public static void main( String[] args) throws  IOException {
      String fromClient; 
      int portnumber = Integer.parseInt(args[0]);
      ServerSocket socket = new ServerSocket(portnumber);
      StringBuilder toClient = new StringBuilder("HTTP/1.1 200 OK\r\n\r\n");

        while(true) {
          Socket connect = socket.accept();
          connect.setSoTimeout(2000);

          BufferedReader inStream = new BufferedReader(new InputStreamReader(connect.getInputStream()));
          DataOutputStream outStream = new DataOutputStream(new DataOutputStream(connect.getOutputStream()));

          while((fromClient = inStream.readLine()) != null &&  fromClient.length() != 0){
                toClient.append(fromClient + "\r\n");
              }

          outStream.writeBytes(toClient.toString());
          connect.close();
          }
    }
}
